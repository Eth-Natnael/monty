push 1
push 2
push 10
push 3
div
pall
